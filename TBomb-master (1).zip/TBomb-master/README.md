# TBomb
This is a SMS Bomber for Debian Based Linux And Termux..

This Script is Only For Educational Purposes or To Prank.
 Do not Use This To Harm Others.
 I Am Not Responsible For The Misuse Of The Script.

The Script Requires A working Net Connection To Work..
No Balance will be deducted for using this script to send SMS...

While Using The Infinite Bomb Use 2-3 Seconds Delay And 15 to 25 Threads For Maximum Performance...
<br>Don't Put Spaces In Between Number Ex- 9999999999

 Make Sure To Update it for New Versions...

 That's All !!!

Make Sure You Are Using python3

To USE the Script Type The Following Commands in Termux...

apt install git

git clone https://github.com/TheSpeedX/TBomb.git

cd TBomb

chmod +x TBomb.sh

./TBomb.sh

Now the Script Will Execute..

## FEATURES 

 Lots Of APIs
 Unlimited Bombing
 International Bombing Available
 Updated Frequently
 Automated Future Updates

# CONTRIBUTORS

 SpeedX    ( Of Course Me ;-) )<br> 
 Crackmind ( Thanks For Finding Couple Of APIs ) <br>
 The Black Hacker ( Thanks For Finding Couple Of APIs ) <br>

# CONTACT
For Any Queries Join Me On WhatsApp!!!
          Group Link: http://bit.do/speedxgit
  <a href="http://bit.do/speedxgit">Join My Group</a>

           Mail: ggspeedx29@gmail.com

           YouTube Channel: https://www.youtube.com/c/GyanaTech
  <a href="https://www.youtube.com/c/GyanaTech">Check My Channel</a>
